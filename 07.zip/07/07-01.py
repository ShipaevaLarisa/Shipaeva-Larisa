word = input()
if len(word) >= 5:
    print(word[4])
else:
    print('НЕТ')
