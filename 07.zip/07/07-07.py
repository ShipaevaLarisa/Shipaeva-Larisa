text = input()
for letter in text:
    print(ord(letter), end=', ')
