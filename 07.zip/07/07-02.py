word = input()
if word[0] == 'а':
    print('ДА')
else:
    print('НЕТ')
