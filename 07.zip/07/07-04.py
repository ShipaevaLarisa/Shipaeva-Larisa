word_1 = input()
word_2 = input()
if word_1[-1] == word_2[0]:
    print('Верно')
else:
    print('Неверно')
