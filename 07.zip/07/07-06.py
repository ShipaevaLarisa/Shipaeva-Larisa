word = input()
for letter in word:
    print(letter)
